<?php


namespace app\ygq\model;
use think\Model;

class Business extends Model
{

}