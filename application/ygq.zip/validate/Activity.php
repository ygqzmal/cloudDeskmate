<?php


namespace app\ygq\validate;



use think\Validate;

class Activity extends Validate
{
//    protected $rule = [
//
//    ];
}